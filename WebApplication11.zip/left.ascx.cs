﻿using System;
using System.Web;

namespace WebApplication11
{
    public partial class left : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!access_sql.yzdl())
            {
                Response.Redirect("/login.aspx");
            }
            else
            {
                u = HttpContext.Current.Request.Cookies["u"].Value;
                p = HttpContext.Current.Request.Cookies["p"].Value;
                uid = HttpContext.Current.Request.Cookies["uid"].Value;
                if (u != "allegro") { gm.Visible = false; }
            }

        }
        public string u = "";
        public string p = "";
        public string uid = "";
    }
}