﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication11.cg
{
    public partial class 广告测试数据分配 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!access_sql.yzdlcg())
            {
                Response.Redirect("/cg/clogin.aspx");
            }
            else
            {
                Session.Timeout = 240;
                u = HttpContext.Current.Request.Cookies["cu"].Value;
                p = HttpContext.Current.Request.Cookies["cp"].Value;
                uid = HttpContext.Current.Request.Cookies["cuid"].Value;
                if (uid != "9")
                {
                    Response.Redirect("/cg/clogin.aspx");
                }
            }

        }
        public string u = "";
        public string p = "";
        public string uid = "";

        public void bindzhy()
        {
            string sql = "";
            rplb.DataSource = null;
            rplb.DataBind();
            string where = "";
            if (txtcr.Text.Trim() != "")
            {
                where += " y.[Conversion_Rate_(Confirmed_Order)]>=" + txtcr.Text.Trim();
            }
            if (txtbs.Text.Trim() != "")
            {
                if (where != "")
                {
                    where += " and ";
                }
                where += " p.[my_sold]>=" + txtbs.Text.Trim();

            }

           
            sql = "select y.Product_Name,y.Parent_SKU,p.my_sold,p.yntitleRcode from YN_LLBB as y left join ProShopeePh as p on y.Parent_SKU=p.itemid where " + where;



            DataSet ds = access_sql.GreatDs(sql);
            if (access_sql.yzTable(ds))
            {
                DataTable dt = ds.Tables[0];
                string wherecodes = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string code = "";
                    string name = dt.Rows[i][0].ToString();
                    string[] codes = name.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries); ;
                    if (codes.Length >= 2)
                    {
                        code = codes[codes.Length - 1];
                        if (code.Length == 8)
                        {
                            wherecodes += "'" + code + "',";
                        }
                    }

                }
                if (wherecodes != "")
                {
                    wherecodes = wherecodes.Substring(0, wherecodes.Length - 1);
                    string sqler = "";

                    sqler = "with ppp as(select y.Parent_SKU,p.my_sold from YN_LLBB as y left join ProShopeePh as p on y.Parent_SKU=p.itemid where y.[Conversion_Rate_(Confirmed_Order)]>=" + txtcr.Text.Trim() + " and p.my_sold>=" + txtbs.Text.Trim() + " group by y.Parent_SKU,p.my_sold) select ppp.my_sold,id,itemid,MainImage,code,Title,Y_1688url,ercipuhuoURL,kefadehaiyun,ROW_NUMBER() OVER(PARTITION BY code ORDER BY code) AS rn from YNBigData left join ppp on YNBigData.PHItemid=ppp.Parent_SKU where PHItemid in (select Parent_SKU from ppp) order by code";





                    DataSet dser = access_sql.GreatDs(sqler);
                    if (access_sql.yzTable(dser))
                    {
                        DataTable dter = dser.Tables[0];
                        DataRow[] itemidList = dter.Select("rn=1");
                        DataTable dtbd = new DataTable();

                        dtbd.Columns.Add("MainImage");
                        dtbd.Columns.Add("code");
                        dtbd.Columns.Add("Title");
                        dtbd.Columns.Add("Y_1688url");
                        dtbd.Columns.Add("kefadehaiyun");
                        dtbd.Columns.Add("Quantity");
                        dtbd.Columns.Add("ercipuhuoURL");

                        for (int i = 0; i < itemidList.Length; i++)
                        {
                            string code = itemidList[i]["code"].ToString();
                            string MainImage = "";

                            string Title = "";
                            string Y_1688url = "";
                            string kefadehaiyun = "";
                            int Quantity = 0;
                            string ercipuhuoURL = "";
                            DataRow[] allrowsbyitemid = dter.Select("code='" + code + "'");
                            bool jx = true;
                            if (dper.SelectedValue == "n")
                            {

                                foreach (DataRow dr in allrowsbyitemid)
                                {
                                    if (dr["ercipuhuoURL"].ToString() != "" && dr["ercipuhuoURL"].ToString() != "0" && dr["ercipuhuoURL"].ToString().ToLower() != "null")
                                    {
                                        jx = false;
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                foreach (DataRow dr in allrowsbyitemid)
                                {
                                    if (dr["ercipuhuoURL"].ToString() != "" && dr["ercipuhuoURL"].ToString() != "0" && dr["ercipuhuoURL"].ToString().ToLower() != "null")
                                    {
                                        ercipuhuoURL = dr["ercipuhuoURL"].ToString();
                                        break;
                                    }
                                }
                                if (ercipuhuoURL == "")
                                {
                                    jx = false;
                                }
                            }
                            if (jx)
                            {
                                foreach (DataRow dr in allrowsbyitemid)
                                {
                                    if (dr["my_sold"].ToString() != "")
                                    {
                                        try
                                        {
                                            Quantity = int.Parse(dr["my_sold"].ToString());
                                        }
                                        catch
                                        {


                                        }

                                        break;
                                    }
                                }
                                foreach (DataRow dr in allrowsbyitemid)
                                {
                                    if (dr["Y_1688url"].ToString().IndexOf("1688") != -1)
                                    {
                                        Y_1688url = dr["Y_1688url"].ToString();
                                        break;
                                    }
                                }
                                if (Y_1688url != "")
                                {
                                    foreach (DataRow dr in allrowsbyitemid)
                                    {
                                        if (dr["kefadehaiyun"].ToString() != "" && dr["kefadehaiyun"].ToString() != "0" && dr["kefadehaiyun"].ToString().ToLower() != "null")
                                        {
                                            kefadehaiyun = dr["kefadehaiyun"].ToString();
                                            break;
                                        }
                                    }
                                }
                                if (kefadehaiyun != "")
                                {
                                    foreach (DataRow dr in allrowsbyitemid)
                                    {
                                        if (dr["MainImage"].ToString() != "" && dr["MainImage"].ToString() != "0" && dr["MainImage"].ToString().ToLower() != "null")
                                        {
                                            MainImage = dr["MainImage"].ToString();
                                            break;
                                        }
                                    }
                                    foreach (DataRow dr in allrowsbyitemid)
                                    {
                                        if (dr["Title"].ToString() != "" && dr["Title"].ToString() != "0" && dr["Title"].ToString().ToLower() != "null")
                                        {
                                            Title = dr["Title"].ToString();
                                            break;
                                        }
                                    }
                                    code = allrowsbyitemid[0]["code"].ToString();
                                    if (MainImage == "" && code != "")
                                    {
                                        MainImage = access_sql.GetOneValue("select  top 1 image from ProShopeePh where itemid =(select top 1 PHItemid from YNBigData where code='" + code + "')");
                                    }
                                }
                                if (Y_1688url != "" && kefadehaiyun != "")
                                {
                                    dtbd.Rows.Add(new object[] { MainImage, code, Title, Y_1688url, kefadehaiyun, Quantity, ercipuhuoURL });
                                }

                            }



                        }

                        if (dtbd != null && dtbd.Rows.Count > 0)
                        {
                            lits.Text = "加载数据" + dtbd.Rows.Count;
                            rplb.DataSource = dtbd;
                            rplb.DataBind();
                        }
                        else
                        {
                            lits.Text = "无数据";
                        }
                    }



                }
            }
            else
            {
                lits.Text = "无数据"; ;
            }
        }

        public void deleteyt(int pid)
        {

            DataTable dt = (DataTable)Session["mdt"];
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["pid"].ToString() == pid.ToString())
                    {
                        dt.Rows.Remove(dt.Rows[i]);
                        break;
                    }
                }


                rplb.DataSource = dt;
                rplb.DataBind();
                Literal1.Text = "<span style='color:red'>加载数据" + dt.Rows.Count + "条</span>";
            }
            else
            {
                lits.Text = "会话状态过期，请关闭浏览器重新打开";
            }



        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txtbs.Text.Trim() != "" || txtcr.Text.Trim() != "")
            {
                bindzhy();
            }
            else
            {
                lits.Text = "请输入查询条件";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void rplb_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            if (e.CommandName == "up")
            {
                lits.Text = "";
                string code = e.CommandArgument.ToString();

                TextBox txtsjbm = e.Item.FindControl("txtsjbm") as TextBox;


                if (txtsjbm.Text.Trim() != "")
                {


                    if (access_sql.T_Update_ExecSql(new string[] { "shangjiabianma" }, new object[] { txtsjbm.Text.Trim().Replace("'", "''") }, "YNBigData", "code='" + code + "'") > 0)
                    {

                        lits.Text = "code:" + code + "更新成功";
                    }
                }
                else
                {
                    lits.Text = "商家编码不能为空";
                    Response.Write("<script>alert('商家编码不能为空');</script>");
                }
            }
        }

        public void clzy()
        {
            int cg = 0;
            bool ky = true;

            for (int i = 0; i < rplb.Items.Count; i++)
            {

                TextBox txtsjbm = rplb.Items[i].FindControl("txtsjbm") as TextBox;
                if (txtsjbm.Text == "")
                {
                    ky = false;
                    lits.Text = "第" + (i + 1) + "商家编码不能为空";
                    Response.Write("<script>alert('第" + (i + 1) + "商家编码不能为空');</script>");
                    break;
                }



            }
            if (ky)
            {
                for (int i = 0; i < rplb.Items.Count; i++)
                {
                    Literal licode = (Literal)rplb.Items[i].FindControl("licode");
                    string code = licode.Text;
                    TextBox txtsjbm = rplb.Items[i].FindControl("txtsjbm") as TextBox;
                    cg += access_sql.T_Update_ExecSql(new string[] { "shangjiabianma" }, new object[] { txtsjbm.Text.Trim().Replace("'", "''") }, "YNBigData", "code='" + code + "'");
                }
                lits.Text = "更新成功" + cg + "个";
            }



        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            clzy();
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            clzy();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

        }
    }
}